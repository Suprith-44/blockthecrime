import React, { useState } from 'react';

const CheckComplaintStatus = () => {
  const [complaintId, setComplaintId] = useState('');
  const [complaintDetails, setComplaintDetails] = useState(null);
  const [error, setError] = useState('');

  const pageStyle = {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    padding: '20px',
  };

  const containerStyle = {
    fontFamily: '"Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
    width: '100%',
    maxWidth: '600px',
    padding: '40px',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: '20px',
    boxShadow: '0 20px 40px rgba(0, 0, 0, 0.1)',
  };

  const headerStyle = {
    color: '#1a237e',
    fontSize: '2rem',
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: '20px',
  };

  const formStyle = {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
  };

  const inputStyle = {
    padding: '10px',
    fontSize: '16px',
    borderRadius: '5px',
    border: '1px solid #bdc3c7',
  };

  const buttonStyle = {
    padding: '10px 20px',
    fontSize: '16px',
    backgroundColor: '#3498db',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
  };

  const detailsStyle = {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '5px',
    marginTop: '20px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // This is where you would typically fetch the complaint details
    // For now, we'll just simulate it with some placeholder data
    if (complaintId.length === 5) {
      setComplaintDetails({
        id: complaintId,
        date: '2023-07-24',
        status: 'Under Investigation',
        description: 'This is a placeholder description for the complaint.',
      });
      setError('');
    } else {
      setError('Invalid complaint ID. Please enter a 5-digit ID.');
      setComplaintDetails(null);
    }
  };

  return (
    <div style={pageStyle}>
      <div style={containerStyle}>
        <h1 style={headerStyle}>Check Complaint Status</h1>
        <form onSubmit={handleSubmit} style={formStyle}>
          <input
            type="text"
            value={complaintId}
            onChange={(e) => setComplaintId(e.target.value)}
            placeholder="Enter your 5-digit complaint ID"
            style={inputStyle}
            maxLength={5}
            required
          />
          <button type="submit" style={buttonStyle}>Check Status</button>
        </form>
        {error && <p style={{ color: 'red', marginTop: '10px' }}>{error}</p>}
        {complaintDetails && (
          <div style={detailsStyle}>
            <h2>Complaint Details</h2>
            <p><strong>Complaint ID:</strong> {complaintDetails.id}</p>
            <p><strong>Date Filed:</strong> {complaintDetails.date}</p>
            <p><strong>Status:</strong> {complaintDetails.status}</p>
            <p><strong>Description:</strong> {complaintDetails.description}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CheckComplaintStatus;
